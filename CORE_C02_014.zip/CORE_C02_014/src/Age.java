import java.util.Scanner;

public class Age {

	public static void main(String[] args) {
		System.out.println("您想要查询的年龄段：\n1.幼年\t2.童年\t3.少年\n4.壮年\t5.中年\t6.老年\n请根据具体情况选择编号：");
		Scanner in = new Scanner(System.in);
		int number = in.nextInt();
		in.close();
		switch(number) {
		case 1:
			System.out.println("幼年的年龄范围是从出生到七岁...");
			break;
		case 2:
			System.out.println("童年的年龄范围是从七岁到十六岁...");
			break;
		case 3:
			System.out.println("少年的年龄范围是从十六岁到二十五岁...");
			break;
		case 4:
			System.out.println("壮年的年龄范围是从二十五岁到四十岁...");
			break;
		case 5:
			System.out.println("中年的年龄范围是从四十岁到六十五岁...");
			break;
		case 6:
			System.out.println("老年的年龄范围是大于六十五岁...");
			break;
		default:
			System.out.println("输入编号非法！");
		}
		
	}

}