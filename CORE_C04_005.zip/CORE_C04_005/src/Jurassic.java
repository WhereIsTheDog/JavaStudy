
public class Jurassic {

	public class Animal {
		public void act(){
			System.out.println("这只动物在水里洗了个澡！");
		}
	}
	
	public class Dinosaur extends Animal {
		public void act(){
			System.out.println("这只恐龙吃掉捕捉到的猎物之后在水里洗了个澡！");
		}
	}
	
	public static void main(String[] args) {
		Jurassic jurassic = new Jurassic();
		Dinosaur dinosaur = jurassic.new Dinosaur();
		dinosaur.act();
	}
}
