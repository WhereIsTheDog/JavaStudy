package cn.campsg.java.experiment;
import java.util.Scanner;

public class LeapYear {
	public static void main(String[] args) {
		 Scanner in=new Scanner(System.in);
		 int year = in.nextInt();
		 in.close();
		 if(year < 2000 || year >3000){
			 System.out.print("请输入2000~3000内的年数！");
			 return;
		 }else {
			 if (year%4 == 0 && year%100 != 0 || year%400 == 0) {
				 System.out.print(year + "年是闰年");
			 }else {
				 System.out.print(year + "年不是闰年");
			 }
		 }
	}
}
