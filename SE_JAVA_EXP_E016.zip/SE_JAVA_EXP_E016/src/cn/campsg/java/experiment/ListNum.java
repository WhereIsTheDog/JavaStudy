package cn.campsg.java.experiment;
import java.util.Scanner;

public class ListNum {

	public static void main(String[] args) {
		int[] nums = new int[5];
		
		Scanner in = new Scanner(System.in);
		for(int n=0; n<5; n++) {
			System.out.print("�������" + n + "�����֣����س���");
			nums[n] = in.nextInt();;
		}
		in.close();
		
		int temp;
		for(int i=0; i<4; i++) {
			for(int j = i+1; j<5; j++) {
				if(nums[i] > nums[j]) {
					temp = nums[i];
					nums[i] = nums[j];
					nums[j] = temp;
				}
			}
		}
		
		System.out.println("����֮�������Ϊ��");
		for(int x : nums) {
			System.out.print(x+" ");
		}
	}

}
