package cn.campsg.java.experiment;

public class MainClass {

	public static void main(String[] args) {
		Student student = new Student();
		student.name = "黄世仁";
		student.age = 24;
		student.sex = true;
		student.score = 59.0f;
		
		System.out.println("姓名："+ student.getName());
		System.out.println("年龄："+ student.getAge());
		System.out.println("性别："+ student.getSex());
		System.out.print("分数："+ student.getScore());
	}

}
