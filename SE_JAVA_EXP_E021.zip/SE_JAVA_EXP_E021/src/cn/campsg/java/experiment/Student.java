package cn.campsg.java.experiment;

public class Student {
	
	String name;
	int age;
	boolean sex;
	float score;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		if(age < 18) {
			this.age = 18;
		}
		else{
			this.age = age;
		}
	}

	public String getSex() {
		if (sex == true) {
			return("男");
		}
		else {
			return("女");
		}
	}

	public void setSex(boolean sex) {
		this.sex = sex;
	}

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public Student() {
		super();
		this.name = "";
		this.age = 0;
		this.sex = true;
		this.score = 0.0f;
	}

	public Student(String name, int age, boolean sex, float score) {
		super();
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.score = score;
	}
	
}
