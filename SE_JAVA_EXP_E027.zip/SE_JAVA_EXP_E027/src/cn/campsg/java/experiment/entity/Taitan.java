package cn.campsg.java.experiment.entity;

public class Taitan {

	int blood = 700;

	public int getBlood() {
		return blood;
	}

	public void setBlood(int blood) {
		this.blood = blood;
	}
	
	public void attack(Zeus zeus) {
		int zeusblood = zeus.getBlood();
		int hurt = (int)(Math.random()*100);
		zeusblood = zeus.getBlood();
		zeusblood = zeusblood - hurt;
		zeus.setBlood(zeusblood);
		System.out.println("泰坦攻击宙斯，宙斯扣血:" + hurt + ",剩余：" + zeusblood);
	}
	
}
