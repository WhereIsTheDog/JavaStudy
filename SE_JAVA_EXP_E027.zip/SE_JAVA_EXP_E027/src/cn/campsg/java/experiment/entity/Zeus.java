package cn.campsg.java.experiment.entity;

public class Zeus {

	int blood = 1000;

	public int getBlood() {
		return blood;
	}

	public void setBlood(int blood) {
		this.blood = blood;
	}
	
	public void attack(Taitan taitan) {
		int taitanblood = taitan.getBlood();
		int hurt = (int)(Math.random()*70);
		taitanblood = taitan.getBlood();
		taitanblood = taitanblood - hurt;
		taitan.setBlood(taitanblood);
		System.out.println("宙斯攻击泰坦，泰坦扣血:" + hurt + ",剩余：" + taitanblood);
	}	
	
}
