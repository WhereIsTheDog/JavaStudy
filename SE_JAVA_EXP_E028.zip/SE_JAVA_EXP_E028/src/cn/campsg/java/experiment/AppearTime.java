package cn.campsg.java.experiment;
import java.util.Scanner;

public class AppearTime {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		System.out.println("请输入需要验证的字符串：");
		String line = in.nextLine();
		in.close();
		
		int sum = 0;
		for(int i = 0;i < line.length()-1; i++) {
			if(line.substring(i, i+2).equals("sh")) {
				sum++;
			}
		}
		
		System.out.println("sh在字符串中一共出现了" + sum + "次");
		
	}

}
