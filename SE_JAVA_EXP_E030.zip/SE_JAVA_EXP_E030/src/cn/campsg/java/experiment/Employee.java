package cn.campsg.java.experiment;

public class Employee {

	String no;
	String name;
	float salary;
	String department;
	/**
	 * @return the no
	 */
	public String getNo() {
		return no;
	}
	/**
	 * @param no the no to set
	 */
	public void setNo(String no) {
		this.no = no;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the salary
	 */
	public float getSalary() {
		return salary;
	}
	/**
	 * @param salary the salary to set
	 */
	public void setSalary(float salary) {
		this.salary = salary;
	}
	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}
	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}
	
	public Employee() {
		super();
	}
	
	public Employee(String no, String name, float salary, String department) {
		super();
		this.no = no;
		this.name = name;
		this.salary = salary;
		this.department = department;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object o) {
		
		if(o == null) {
			return false;
		}
		
		if(!(o instanceof Employee)) {
			return false;
		}
		
		Employee emp = (Employee)o;
		
		if(!emp.getNo().equals(this.getNo())) {
			return false;
		}else {
			return true;
		}
		
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		
		StringBuffer buffer = new StringBuffer();
		buffer.append("工号: " + this.no + ",姓名: " + this.name  + ",部门: " + this.department + ",薪水: " + this.salary);
		
		return buffer.toString();
	}
	
	
	
}
