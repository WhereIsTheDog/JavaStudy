package frame;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.Color;
import javax.swing.JTextPane;
import javax.imageio.ImageIO;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.Window.Type;
import javax.swing.JLabel;

public class Mainframe extends JFrame {

	private JPanel contentPane;
	/**
	 * @wbp.nonvisual location=-45,134
	 */
	private final JTextPane textPane = new JTextPane();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mainframe frame = new Mainframe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Mainframe() {
		setType(Type.POPUP);
		setTitle("JAVA\u5B57\u7B26\u753B");
		setBackground(Color.DARK_GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 452, 656);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		JFileChooser chooser =new JFileChooser();
		JTextPane textPane_1 = new JTextPane();
		JButton button = new JButton("\u9009\u62E9\u56FE\u7247");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				FileNameExtensionFilter filter = new FileNameExtensionFilter("image","jpg","png");
				chooser.setFileFilter(filter);
				int value=chooser.showOpenDialog(null);
				if(value==JFileChooser.APPROVE_OPTION) {
					File file=chooser.getSelectedFile();
					textPane_1.setText(file.getAbsolutePath());
					try {

						BufferedImage image = ImageIO.read(file);
						JFrame frame2 = new JFrame();
					    JLabel label = new JLabel(new ImageIcon(image));
					    frame2.getContentPane().add(label, BorderLayout.CENTER);
					    frame2.pack();
					    frame2.setVisible(true); 

					     
					 	}catch (IOException e1) {
					 		// TODO Auto-generated catch block
					 		e1.printStackTrace();
					}
				}
				
			}
		});
		
		JButton btnNewButton = new JButton("\u5F00\u59CB\u8F6C\u6362");
		btnNewButton.addMouseListener(new MouseAdapter() {
			 @Override
			public void mouseClicked(MouseEvent e) {
				String path=textPane_1.getText();
				BufferedImage oriImg = null;
				try {
					oriImg = ImageIO.read(new File(path));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				int width;
				int height;
				int rgb;

				width = oriImg.getWidth();
				height = oriImg.getHeight();
				BufferedImage BinaryImage;
				BinaryImage = new BufferedImage(width,height,BufferedImage.TYPE_BYTE_GRAY);
				//�ַ��ɼ򵥵����ӣ�������ʾ��ͬ�Ҷ�
				String str="@#$%*o!(^.";
				int r,g,b,index;
				int grey;
				//�ַ���·��
				String txtDir=1+".txt";
				//д���ı��ļ�
				try(FileWriter fw = new FileWriter(txtDir)){
				for(int i=0;i<height;i+=8) {
					for(int j=0;j<width;j+=5) {
						rgb = oriImg.getRGB(j, i);
						r = (rgb & 0xff0000) >>> 16;
						g = (rgb & 0xff00) >>> 8;
						b = (rgb & 0xff);
						grey =(int)(0.299*r+0.587*g+0.114*b);
						
						index = Math.round((grey*str.length())/255);
						if(index>=str.length()) {
							fw.write(" ");
						}
						else fw.write(str.charAt(index));
						
					}
					fw.write("\r\n");

					
				}} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				System.out.println("................................�������ַ���......................");
				//���ַ����ļ�
				Runtime rt = Runtime.getRuntime();
				try {
					rt.exec("cmd.exe  /c "+txtDir);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				 				 
				 
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(textPane_1, GroupLayout.PREFERRED_SIZE, 304, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(button, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(textPane_1, Alignment.LEADING)
						.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
							.addComponent(button)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(535, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
