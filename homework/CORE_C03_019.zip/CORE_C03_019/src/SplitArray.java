
public class SplitArray {

	public static void main(String[] args) {
		
		String line = "2008/09/10";
		String[] newline = line.split("/");
		for(int i = 0;i < newline.length; i++) {
			System.out.println(newline[i]);
		}
		
	}

}
