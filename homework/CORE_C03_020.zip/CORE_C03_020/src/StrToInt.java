
public class StrToInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String text = "1234";
		System.out.println(Integer.valueOf(text));
	}

}
