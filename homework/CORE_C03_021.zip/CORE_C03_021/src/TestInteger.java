
public class TestInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer x = 123;
		x.intValue();
		x++;
		Integer y = Integer.valueOf(x);
		System.out.println("y=" + y);
	}

}
