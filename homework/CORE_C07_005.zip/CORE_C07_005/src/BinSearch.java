import java.util.ArrayList;
import java.util.Collections;

public class BinSearch {

	public static int fuckindex(ArrayList<Integer> fuckindex, int fuckkey) {
		return Collections.binarySearch(fuckindex,fuckkey);
	}
	
	public static void main(String[] args) {
		Integer a[] = {76,4,786,43,21,432,10};
		ArrayList<Integer> ilist = new ArrayList<>();
		Collections.addAll(ilist, a);
		System.out.println(fuckindex(ilist,4));
	}

}
