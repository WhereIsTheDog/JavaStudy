import java.util.HashMap;
import java.util.Iterator;

public class ClassManager {
	private HashMap<String, Student> map = new HashMap<String, Student>();
	
	public void saveStudent(String id, Student student) {
		map.put(id, student);
	}
	public String checkAllStudent() {
		String fuckreturn = "";
		
		Iterator<String> iditerator = map.keySet().iterator();
		while(iditerator.hasNext()) {
			//fuckreturn += iditerator.next();
			String ls = iditerator.next();
			fuckreturn += "学号："+ls+"，"+ map.get(ls).toString()+"\n";
			//fuckreturn.concat(map.get(id.next()).toString()+"\n");
			
		}
		
		return fuckreturn;
	}
}

