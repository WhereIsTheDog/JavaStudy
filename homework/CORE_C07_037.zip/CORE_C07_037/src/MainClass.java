
public class MainClass {

	public static void main(String[] args) {
		ClassManager classmanager = new ClassManager();
		Student student1 = new Student("Roger", 21, true);
		Student student2 = new Student("July", 20, false);
		classmanager.saveStudent("115599", student1);
		classmanager.saveStudent("335577", student2);
		System.out.println(classmanager.checkAllStudent());
	}

}
