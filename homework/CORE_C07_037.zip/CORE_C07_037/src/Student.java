
public class Student {
	String name;
	int age;
	boolean sex;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}
	/**
	 * @return the sex
	 */
	public boolean isSex() {
		return sex;
	}
	/**
	 * @param sex the sex to set
	 */
	public void setSex(boolean sex) {
		this.sex = sex;
	}
	public Student(String name, int age, boolean sex) {
		this.name = name;
		this.age = age;
		this.sex = sex;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		String sex = null;
		if(this.sex == true) {
			sex = "男";
		}else {
			sex = "女";
		}
		return ("姓名："+this.name+"，年龄："+this.age+"，性别："+sex);
	}
	
}
