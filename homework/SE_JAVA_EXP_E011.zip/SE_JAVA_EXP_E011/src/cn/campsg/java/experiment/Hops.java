package cn.campsg.java.experiment;
import java.util.Scanner;

public class Hops {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.print("请输入跳数计算的边界值：");
		int finish = in.nextInt();
		in.close();
		int sum = 0;
		int i = 1;
		while(i <= finish) {
			if (i % 10 != 3) {
				sum = sum+i;
			}
			i++;
		}
		System.out.println(" 1~" + finish + "，跳过个位数字是3的数字之和：" + sum);
		
	}

}
