package cn.campsg.java.experiment;

public class PrintTriangle {

	public static void main(String[] args) {
		int row = 5;
		int i = 0;
		int stars = 0;
		int spaces = 0;
		while(i < 5) {
			stars = i*2+1;
			spaces = row-i-1;
			int star = 0;
			int space = 0;
			while (space < spaces) {
				System.out.print(" ");
				space++;
			}
			while (star < stars) {
				System.out.print ("*");
				star++;
			}
			System.out.print("\n");
			i++;
		}

	}

}
