package cn.campsg.java.experiment;

public class MainClass {
	public static int sum(String numberStr) {
		int sum = 0;
		String[] arr = numberStr.split(";");
		for(int i=0; i<arr.length; i++) {
			sum = sum + 	Integer.valueOf(arr[i].substring(arr[i].length()-1,arr[i].length()));
		}
		return sum;
	}
	
	public static void main(String[] args) {
		String str = new String("105;20;30;40;50;55;26;7");
		System.out.println("原字符数列："+str);
		System.out.println("数列个位数求和结果："+sum(str));
	}
}
