package cn.campsg.java.experiment;

import cn.campsg.java.experiment.entity.*;
import cn.campsg.java.experiment.Company;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employe employe = new Employe("糖糖", 5, 6000);
		Hrstaff hrstaff = new Hrstaff("HR");
		
		Company company = new Company();
		
		company.appraisals(employe);
		company.appraisals(hrstaff);
	}

}
