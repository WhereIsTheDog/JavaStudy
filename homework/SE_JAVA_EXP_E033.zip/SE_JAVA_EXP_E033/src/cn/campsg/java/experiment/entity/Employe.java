package cn.campsg.java.experiment.entity;

public class Employe {

	String name;
	int level;
	int salary;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the level
	 */
	public int getLevel() {
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel(int level) {
		this.level = level;
	}
	/**
	 * @return the salary
	 */
	public int getSalary() {
		return salary;
	}
	/**
	 * @param salary the salary to set
	 */
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public Employe() {
		super();
	}
	
	public Employe(String name, int level, int salary) {
		super();
		this.name = name;
		this.level = level;
		this.salary = salary;
	}
	
	public void work() {
		System.out.println(this.name + "按领导的要求完成任务！");
	}
	
	public String looupSalary(int level) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
