package cn.campsg.java.experiment;

public interface ShapeCalc {
	
	public float calcPerim();
	public float calcArea();
	
}
