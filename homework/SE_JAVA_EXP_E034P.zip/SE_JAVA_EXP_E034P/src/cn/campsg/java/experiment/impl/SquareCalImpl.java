package cn.campsg.java.experiment.impl;

import cn.campsg.java.experiment.ShapeCalc;

public class SquareCalImpl implements ShapeCalc{
	private float length;

	/**
	 * @return the length
	 */
	public float getLength() {
		return length;
	}

	/**
	 * @param length the length to set
	 */
	public void setLength(float length) {
		this.length = length;
	}

	public SquareCalImpl() {
		super();
	}
	
	public float calcPerim() {
		float peri = length * 4 ;
		return peri ;
	}
	
	public float calcArea() {
		float area= length * length ;
		return area;
	}
	
}
