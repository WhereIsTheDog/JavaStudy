package cn.campsg.java.experiment;

import java.text.ParseException;
import java.util.Date;
import cn.campsg.java.experiment.entity.*;

public class MainClass {

	public static void main(String[] args) {
		
		java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd");
		// 创建办公室建造者
		Builder office = new OfficeBuilder();
		// 创建别墅建造者
		Builder villa = new VillaBuilder();
	    Date oDate =null ;
	    Date vDate =null ;
	    try {
	    	// 办公室的实际完工时间
	    	oDate =format.parse("2016-10-11");
	    	// 别墅的实际完工时间
	    	vDate =format.parse("2016-10-16");
	    }catch (ParseException e) {
	    	e.printStackTrace();
	    }
	    // 建造办公室
	    office.construct(oDate);
	    // 建造别墅
	    villa.construct(vDate);
	}

}
