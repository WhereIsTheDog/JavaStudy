package cn.campsg.java.experiment;

import cn.campsg.java.experiment.entity.*;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractSinger s = new PopSinger(); 
		s.introduce();
		s.sing();
	}

}
