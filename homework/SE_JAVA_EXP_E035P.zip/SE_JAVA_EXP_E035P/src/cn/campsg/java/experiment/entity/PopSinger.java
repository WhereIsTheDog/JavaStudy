package cn.campsg.java.experiment.entity;

public class PopSinger extends AbstractSinger {
	
	public void sing() {
		System.out.println("我是唱流行乐的。");
	}
	
}
