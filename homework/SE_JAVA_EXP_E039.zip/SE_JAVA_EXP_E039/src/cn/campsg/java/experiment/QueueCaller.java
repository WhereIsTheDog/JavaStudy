package cn.campsg.java.experiment;

import java.util.ArrayList;

public class QueueCaller {
	private ArrayList<String> queue;

	public QueueCaller() {
		this.queue = new ArrayList<String>();
	}
	
	public int size() {
		return this.queue.size();
	}
	
	public void fetchNumber(String patient) {
		this.queue.add(patient);
		System.out.println(patient+"前面还有"+(size()-1)+"位在等候就诊。");
	}
	
	public void showPatients() {
		for(int i=0; i<size(); i++) {
			if(size() == 0) {
				break;
			}else {				
				System.out.println(this.queue.get(i)+"候诊中");
			}
		}
	}
	
	public void callNumber() {
		for(int i=0; i<size(); i++) {
			System.out.println("请患者："+this.queue.get(i)+" 到诊室就诊！");
			this.queue.remove(i);
		}
	}
}
