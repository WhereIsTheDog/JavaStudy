package cn.campsg.java.experiment.entity;

public class Awards {
	private String name;
	private int count;
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the count
	 */
	public int getCount() {
		return count;
	}
	/**
	 * @param count the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}
	public Awards() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Awards(String name, int count) {
		super();
		this.name = name;
		this.count = count;
	}
}
