package cn.campsg.java.experiment.entity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import cn.campsg.java.experiment.entity.Awards;;

public class DrawReward {
	private Map<Integer,Awards> rwdPool = null;

	public DrawReward() {
		this.rwdPool = new HashMap<Integer, Awards>();
		Awards tedengjiang = new Awards("特等奖",1);
		Awards yidengjiang = new Awards("一等奖",4);
		Awards erdengjiang = new Awards("二等奖",6);
		Awards sandengjiang = new Awards("三等奖", 100);
		this.rwdPool.put(8, tedengjiang);
		this.rwdPool.put(1, yidengjiang);
		this.rwdPool.put(2, erdengjiang);
		this.rwdPool.put(0, sandengjiang);
	}
	
	public void draward(int rdKey) {
		Awards aw = this.rwdPool.get(rdKey);
		if(aw == null) {
			return;
		}else if (aw.getCount() <1) {
			System.out.println(aw.getName()+"+，该奖项已抽完。");
		}else {
			aw.setCount(aw.getCount() - 1);
			System.out.println("抽奖结果：" + aw.getName());
		}
	}
	
	public void showSurplus() {
		Iterator<Awards> itor;
		itor = rwdPool.values().iterator();
		while(itor.hasNext()) {
			Awards aw = itor.next();
			System.out.println(aw.getName() + ";剩余奖项数量：" + aw.getCount());
		}
		
	}
}
