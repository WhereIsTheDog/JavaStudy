package cn.campsg.java.experiment;

import java.io.IOException;
import java.net.Socket;
import cn.campsg.java.experiment.service.*;

public class Clients {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String srvIP = "127.0.0.1";
		int port = 9999;
		int srvPort = port;
		
		try {
			Socket socket1 = new Socket(srvIP,srvPort);
			Socket socket2 = new Socket(srvIP,srvPort);
			Socket socket3 = new Socket(srvIP,srvPort);
			Socket socket4 = new Socket(srvIP,srvPort);
			
			new Thread(new AskClient(socket1,"CA1893"),"问询者@CA1893").start();
			new Thread(new AskClient(socket2,"CZ3590"),"问询者@CZ3590").start();
			new Thread(new AskClient(socket3,"FM9802"),"问询者@FM9802").start();
		 	new Thread(new AskClient(socket4,"XS9882"),"问询者@XS9882").start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
