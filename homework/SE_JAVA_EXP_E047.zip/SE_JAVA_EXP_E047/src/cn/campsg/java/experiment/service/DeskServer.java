package cn.campsg.java.experiment.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class DeskServer implements Runnable {
	
	private Socket socket = null;

	public DeskServer(Socket socket) {
		super();
		this.socket = socket;
	}
	
	public void run() {
		try {
			InputStream in = null;
			OutputStream os = null;
			os = socket.getOutputStream();
			in = socket.getInputStream();
			byte[] bytes = new byte[in.available()];
			in.read(bytes);
			String ask = new String(bytes).trim();
			System.out.println("服务端@前端咨询内容为:"+ask);
			
			String result = "" ;
			if(ask.contains("CA")){
				result="乘客您好，国航在2楼9号登机口!\r" ;
			}else if(ask.contains("CZ")){
				result="乘客您好，南航在1楼6号登机口!\r" ;
			}else if(ask.contains("FM")){
				result="乘客您好，上航在2楼12号登机口!\r" ;
			}else{
				result="乘客您好，抱歉，暂无您的航班登机信息!\r" ;
			}
			 
			try {
				os.write(result.getBytes("UTF-8"));
				os.flush();      
			}catch (IOException e) {
				System.out.println("客户端已关闭,等待重新连接……@"+e.getMessage()); 
			}finally{
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("服务端处理客户端连接时异常："+e.getMessage());
		}
		
	}


}
